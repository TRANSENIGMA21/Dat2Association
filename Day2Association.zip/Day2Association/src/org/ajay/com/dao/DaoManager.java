package org.ajay.com.dao;

import java.util.List;











import org.ajay.com.entities.Address;
import org.ajay.com.entities.Author;
import org.ajay.com.entities.Book;
import org.ajay.com.entities.Cources;
import org.ajay.com.entities.Customer;
import org.ajay.com.entities.Player;
import org.ajay.com.entities.Team;
import org.ajay.com.entities.Trainee;
import org.ajay.com.resources.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DaoManager {
	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoManager() {
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddCustomer_Address(Customer customer, Address address){
		session=factory.openSession();
		session.beginTransaction();
		try {
			session.save(address);
			customer.setAddress(address);
			session.persist(customer);
			session.getTransaction().commit();
			status=true;
			
			
			
		} catch (HibernateException ex) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		return status;
	}
	public Query GetAll(){
		session=factory.openSession();
		return session.createQuery("select cust.customerId, cust.name, addr.street,"
				+"addr.city from Customer cust inner join cust.address addr");
		
	}
	
	public boolean AddBook_Author(Book book,Author author){
		session=factory.openSession();
		session.beginTransaction();
		try {
			author.setBook(book);
			book.setAuthor(author);
			session.save(book);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	public boolean AddTeam_Player(Team team,List<Player> playerlist){
		session=factory.openSession();
		session.beginTransaction();
		try {
			team.setPlayer(playerlist);
			
			
			session.save(team);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	public List<Team> getAllAndPlayer(){
		session=factory.openSession();
		
		
		return session.createQuery("from Team").list();
		
		
	}
	
	
	public boolean AddTrainee_Cources(List<Trainee> traineeList, List<Cources> cources){
		session=factory.openSession();
		session.beginTransaction();
		try {
			for(Trainee trainee:traineeList){
				trainee.setCources(cources);
				session.save(trainee);
			}
			
			
			
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	
	
	
	
	
	

}
