package org.ajay.com.resources;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	

	
	public static SessionFactory GetFactory(){
		return new Configuration().configure("org/ajay/com/resources/hibernate.cfg.xml").buildSessionFactory();
		
	}

}
