package org.ajay.com.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="Cource")
public class Cources {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Cource_Id")
	private int courceId;
	@Column(name="Cource_Name")
	private String courceName;
	
	
	@ManyToMany(mappedBy="cources")
	private List<Trainee> traineeList;
	public int getCourceId() {
		return courceId;
	}
	public void setCourceId(int courceId) {
		this.courceId = courceId;
	}
	public String getCourceName() {
		return courceName;
	}
	public void setCourceName(String courceName) {
		this.courceName = courceName;
	}
	public List<Trainee> getTraineeList() {
		return traineeList;
	}
	public void setTraineeList(List<Trainee> traineeList) {
		this.traineeList = traineeList;
	}
	
	
	
	
	

}
