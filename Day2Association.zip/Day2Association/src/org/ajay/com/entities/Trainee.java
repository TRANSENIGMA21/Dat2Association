package org.ajay.com.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="Trainee")
public class Trainee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Trainee_Id")
	private int traineeId;
	
	@Column(name="Trainee_NAme")
	private String traineeName;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="Trainee_cources",
	joinColumns={@JoinColumn(name="Trainee_Id")},
	inverseJoinColumns={@JoinColumn(name="cource_Id")})
	private List<Cources> cources;
	
	
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public List<Cources> getCources() {
		return cources;
	}
	public void setCources(List<Cources> cources) {
		this.cources = cources;
	}
	
	
	

}
