package org.ajay.com.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.ajay.com.dao.DaoManager;
import org.ajay.com.entities.Address;
import org.ajay.com.entities.Author;
import org.ajay.com.entities.Book;
import org.ajay.com.entities.Cources;
import org.ajay.com.entities.Customer;
import org.ajay.com.entities.Player;
import org.ajay.com.entities.Team;
import org.ajay.com.entities.Trainee;

public class TestApp {
	public static void main(String[] args) {
		
		DaoManager dao= new DaoManager();
		/*
		List<Trainee> traineeList=new ArrayList<Trainee>();
		List<Cources> courceList=new ArrayList<Cources>();
		
		
		Trainee trainee=new Trainee();
		trainee.setTraineeName("sanjay");
		traineeList.add(trainee);
		
		trainee=new Trainee();
		trainee.setTraineeName("usha");
		traineeList.add(trainee);
		
		trainee=new Trainee();
		trainee.setTraineeName("Sudha");
		traineeList.add(trainee);
		
		Cources cources=new Cources();
		cources.setCourceName("Hibernate");
		cources.setTraineeList(traineeList);
		courceList.add(cources);
		dao.AddTrainee_Cources(traineeList, courceList);
		
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		/*for(Team team: dao.getAllAndPlayer()){
			System.out.println(team.getTeamName());
			for(Player player: team.getPlayer()){
				System.out.println(player.getPlayerName());
			}
		}*/
		
		
		
		
		
		
		
		
		
		
		
	/*	Team team=new Team();
		team.setTeamName("RCB");
		
		
		
		List<Player> playerList=new ArrayList<Player>();
		Player player=new Player();
		player.setPlayerName("Virat kohli");
		player.setTeam(team);
		playerList.add(player);
		
		player=new Player();
		player.setPlayerName("KL Rahul");
		player.setTeam(team);
		playerList.add(player);
		
		player=new Player();
		player.setPlayerName("AV Diviliars");
		player.setTeam(team);
		playerList.add(player);
		
		dao.AddTeam_Player(team, playerList);*/
	
		
		
		
		
		
		
		
		Book book = new Book();
		book.setName("java");
		book.setDop(new Date(97,1,1));
		Author author= new Author();
		author.setName("Gosling");
		dao.AddBook_Author(book, author);
		
		
		
		
		
		
		
		
		/*Iterator itr= dao.GetAll().iterate();
		System.out.println("CustomerId"+"\t"+"Sreet"+"\t"+"City");
		while(itr.hasNext()){
			Object[] obj=(Object[]) itr.next();
			System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]);*/
		}
		
/*
		Address address= new Address();
		address.setStreet("balaji strert");
		address.setCity("potheri");
		 
		Customer customer = new Customer();
		customer.setName("mukesh");
		customer.setDob(new Date(1991,8,26));
		dao.AddCustomer_Address(customer, address);*/
		
	}


